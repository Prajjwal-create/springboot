package com.coforge.training.webservice;

public class Calculator {
	
	public int add(int a,int b)
    {
        return(a+b);
       
    }
   
    public int mul(int a,int b)
    {
        return(a*b);
    }
    
    public int sub(int a,int b)
    {
        return(a-b);
       
    }
   
    public int dib(int a,int b)
    {
        return(a/b);
    }

}
