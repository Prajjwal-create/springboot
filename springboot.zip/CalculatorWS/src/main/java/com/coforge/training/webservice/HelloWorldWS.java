package com.coforge.training.webservice;

public class HelloWorldWS {
	
	
	public String sayHello(String msg)
    {
        return "Hello from SOAP Web Service by "+msg;
    }
	
	
	public int square(int a)
	{
		return (a*a);
	}

}
