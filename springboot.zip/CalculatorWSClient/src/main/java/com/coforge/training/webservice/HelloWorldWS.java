/**
 * HelloWorldWS.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.coforge.training.webservice;

public interface HelloWorldWS extends java.rmi.Remote {
    public int square(int a) throws java.rmi.RemoteException;
    public java.lang.String sayHello(java.lang.String msg) throws java.rmi.RemoteException;
}
