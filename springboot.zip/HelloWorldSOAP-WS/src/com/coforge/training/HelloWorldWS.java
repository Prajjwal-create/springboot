package com.coforge.training;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.xml.ws.Endpoint;

@WebService
@SOAPBinding(style= SOAPBinding.Style.DOCUMENT)
public class HelloWorldWS {

	@WebMethod
	public String sayHello(String msg)
     {
		return "HEllo from Soap Web Service ny "+msg;
	}
	
	public static void main(String[] args) {
	
		Endpoint.publish("http://localhost:8888/helloWs", new HelloWorldWS()); 
	
	}

}
