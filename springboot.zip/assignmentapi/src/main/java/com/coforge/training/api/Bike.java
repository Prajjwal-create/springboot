package com.coforge.training.api;

public class Bike {
	
	private Long id;
	  private String Bike;
	
	  
	public Bike() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getBike() {
		return Bike;
	}


	public void setBike(String bike) {
		Bike = bike;
	}

	

}
