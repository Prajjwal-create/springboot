package com.coforge.training.api;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;



public class RestClintApplication {

	@Bean

	 public CommandLineRunner run(RestTemplate rt) throws Exception

	{


	 

	 return args -> {

	         Jokes[] j=rt.getForObject("https://official-joke-api.appspot.com/jokes/ten", Jokes[].class);

	        List<Jokes> objects = new ArrayList<Jokes>();

	        objects=Arrays.asList(j);

	        for (Jokes s : objects) {

	 System.out.println(s);

	}

	};

	}

}
