package com.coforge.training.inventory.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssignmentapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssignmentapiApplication.class, args);
	}

}
