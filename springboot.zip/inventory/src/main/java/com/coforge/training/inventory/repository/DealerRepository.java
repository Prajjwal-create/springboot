package com.coforge.training.inventory.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.coforge.training.inventory.model.Dealer;

public interface DealerRepository extends JpaRepository<Dealer, Long> {

	//This interace has save(),findAll(),findById(),deleteById(),count()
    //etc.. inbulilt methods of jpa repository for various db operations
	//Ths interface will be iplimented by the class automatically
	
}
