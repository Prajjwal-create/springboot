package com.coforge.training.inventory.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.coforge.training.inventory.model.Product;


// It impliment all the crud method
public interface ProductRepository extends JpaRepository<Product, Long> {

	
	
}
