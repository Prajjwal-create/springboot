package com.coforge.training.inventory.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.coforge.training.inventory.model.Dealer;
import com.coforge.training.inventory.repository.DealerRepository;
import com.coforge.training.inventory.repository.UserRepository;


// .@Service annotates classes at the service layer   indicate that they're holding the business logic.
@Service      
@Transactional
public class LoginService {
	
	@Autowired
  private DealerRepository derpo;	
	
	@Autowired
	private UserRepository urepo;
	
	public void saveDealer(Dealer d)
	{
	  derpo.save(d); //it invoke save method of jpa repository
	}
	
	public Dealer findDealerByEmail(String email)
	{
		return urepo.findByEmail(email);
	}
	

}
