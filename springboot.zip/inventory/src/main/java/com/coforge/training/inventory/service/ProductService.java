package com.coforge.training.inventory.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.coforge.training.inventory.model.Product;
import com.coforge.training.inventory.repository.ProductRepository;

@Service
@Transactional
public class ProductService {
	
	@Autowired
	private ProductRepository prepo;
	
	public void saveProduct(Product p)  //user define method
	{
		//save methode is define in jpa repository
		prepo.save(p);
		
	}
	
	public List<Product> getAllProducts()
	{
		return prepo.findAll();   //define in Jparepository
		
	}
	
	public Product getProductById(Long id)
	{
		return prepo.findById(id).get(); //definr in jpa repository
	}
	
	public void deleteProduct(Long id)
	{
		prepo.deleteById(id); //definr in jpa repository
	}

}
