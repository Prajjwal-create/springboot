package com.coforge.training.restwsdemo;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/employeeapi")
public class EmployeeService {
	@GET
	@Path("/empxml")
	@Produces(MediaType.APPLICATION_XML)
	public Employee getXml()
	{
		Employee emp=new Employee();
		emp.setEmpid(101);
		emp.setName("prajjwal");
		emp.setDesignation("GET");
		emp.setSalary(2424.00);
		
		return emp;
	}

}
