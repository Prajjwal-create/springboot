package com.coforge.training.springdemo;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class BookApp {
	
	public static void main(String[] args)
	{
		@SuppressWarnings("deprecation")
		   Resource r=new ClassPathResource("BookConfig.xml");
	        BeanFactory f=new XmlBeanFactory(r);
	       
	        Book b=(Book)f.getBean("bk");
	        b.show();
	       
	        //Book b1=new Book(101,"aaaaaaaaa",500);
	}

}
