package com.coforge.training.springdemo;

public class Candidate {

	
	private int id;
    private String name;
    
    private Address a; //Aggregation
    
    public Candidate() {
    	
    	System.out.println("candidate details");
    }

	public Candidate(int id, String name, Address a) {
		super();
		this.id = id;
		this.name = name;
		this.a = a;
	}
    
	void disp()
    {
        System.out.println(id+" "+name);
        System.out.println(a);  // invoke toString() method of Address class
    }
    
}
