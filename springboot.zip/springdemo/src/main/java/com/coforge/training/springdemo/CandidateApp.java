package com.coforge.training.springdemo;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

class CandidateApp {

	
	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Resource r=new ClassPathResource("CandidateConfig.xml");
        BeanFactory f=new XmlBeanFactory(r);
       
        Candidate b=(Candidate)f.getBean("cd");
        b.disp();
		

	}

}
