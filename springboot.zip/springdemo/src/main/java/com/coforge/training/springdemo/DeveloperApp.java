package com.coforge.training.springdemo;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class DeveloperApp {
	
	
	public static void main(String[] args)
	{
		@SuppressWarnings("deprecation")
		Resource r=new ClassPathResource("DeveloperConfig.xml");
        BeanFactory f=new XmlBeanFactory(r);
       
        Developer b=(Developer)f.getBean("d");
        b.display();
	}

}
