package com.coforge.training.springdemo;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
@SuppressWarnings("deprecation")
public class EmployeeTest {

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Resource r=new ClassPathResource("EmployeeConfig.xml");
        BeanFactory f=new XmlBeanFactory(r);
       
        Employee e=(Employee)f.getBean("emp");
        e.display();

	}

}
