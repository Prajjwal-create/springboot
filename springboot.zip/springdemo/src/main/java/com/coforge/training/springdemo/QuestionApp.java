package com.coforge.training.springdemo;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class QuestionApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		@SuppressWarnings("deprecation")
		Resource r=new ClassPathResource("QuestionConfig.xml");
        BeanFactory f=new XmlBeanFactory(r);
       
        Question q=(Question)f.getBean("quest1");
        q.displayInfo();

	}

}
