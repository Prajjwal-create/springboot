package com.coforge.training.springdemo;


// creating  BEAN CLASS
public class Student {
	
	String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public void display()
    {
        System.out.println("Hello "+name);
    }

}
