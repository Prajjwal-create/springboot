package com.coforge.training.springjdbc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.coforge.training.springjdbc.dao.EmployeeDao;
import com.coforge.training.springjdbc.model.Employee;

@Controller
public class EmployeeController {
	@Autowired
	EmployeeDao empdao; //will inject dao form xml files
     // displays form to input data. Emp is request Object to form or model
	@RequestMapping("/addEmp")
	public String showEmpForm(Model m)
	{
		Employee emp=new Employee();
		m.addAttribute("emp",emp);
		return "empform";
		/*/*It saves object into database. The @ModelAttribute puts request data
	     *  into model object.*/
	}
	@RequestMapping(value="/save",method=RequestMethod.POST)
	public String saveEmployee(@ModelAttribute("emp") Employee emp)
	{
		empdao.save(emp);
		return "redirect:/viewEmp";
	}
	
	//Provide list of employee in model object
	@RequestMapping("/viewEmp")
	public String viewEmployees(Model m)
	{
		List<Employee> emplist=empdao.getEmployees();
		m.addAttribute("emplist",emplist);
		
		return "viewemp";
	}
	//@Path Variable - It puts url data in to a variable
	//dispaly object data in form for the giver ID
	@RequestMapping("/editemp/{id}")
	public String editEmployee(@PathVariable int id, Model m)
	{
		Employee emp=empdao.getEmpById(id);
		m.addAttribute("command",emp);
		return "editempform";
	}
	
	//update model object
	@RequestMapping(value="/editsave",method=RequestMethod.POST)
	public String saveEditEmployee(@ModelAttribute("emp") Employee emp)
	{
		empdao.update(emp);
		return "redirect:/viewEmp";
		
	}
	@RequestMapping(value="/deleteemp/{id}",method=RequestMethod.GET)
	public String deleteEmployee(@PathVariable int id)
	{
		empdao.delete(id);
		return "redirect:/viewEmp";
	}
	
}
